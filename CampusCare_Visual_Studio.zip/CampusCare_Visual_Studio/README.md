# CampusCare — Visual Studio Code Project

A full-stack MIT-ADT campus complaint management prototype based on the uploaded CampusCare design.

## Technology
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express REST API
- Authentication: bcrypt password hashing + JWT sessions
- Data storage: JSON file (`server/data/db.json`)
- Image attachments: Multer, stored in `server/uploads`

## Requirements
Install **Node.js 18 or newer** and Visual Studio Code.

## Run in Visual Studio Code
1. Extract the ZIP file.
2. Open the extracted `CampusCare_Visual_Studio` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   npm install
   ```

5. Copy `.env.example` to `.env`. Change `JWT_SECRET` to a long random value.
6. Start the server:

   ```bash
   npm start
   ```

7. Open `http://localhost:5000` in your browser.

Do not open `public/index.html` directly. The Express server serves the frontend and API together.

## Demo accounts
| Role | Email | Password |
|---|---|---|
| Student | student@mitadt.edu.in | student123 |
| Department staff | staff@mitadt.edu.in | staff123 |
| Administrator | admin@mitadt.edu.in | admin123 |

New users can register using an `@mitadt.edu.in` email address. Self-registration is limited to Student and Department Staff. The Administrator account is seeded by the server.

## Features
- Login and account registration
- Student complaint submission with optional image attachment
- Categories, campus location, priority and description
- Student view of their own complaints
- Department staff view of all complaints and status updates
- Status timeline: Pending → Assigned → In Progress → Resolved
- Student feedback after resolution
- Admin dashboard, category/status reports and CSV export
- Search and filters

## Main files
```text
CampusCare_Visual_Studio/
├── public/
│   ├── index.html       # Frontend pages and forms
│   ├── styles.css       # Frontend styling
│   └── app.js           # Frontend logic and API calls
├── server/
│   ├── server.js        # Express server and API routes
│   ├── db.js            # JSON data read/write
│   ├── middleware.js    # JWT authentication and role checks
│   ├── data/db.json     # Local data store (created/updated at runtime)
│   └── uploads/         # Complaint image uploads
├── .env.example
├── .gitignore
└── package.json
```

## API endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/complaints`
- `POST /api/complaints` (multipart form data)
- `GET /api/complaints/:id`
- `PATCH /api/complaints/:id/status`
- `POST /api/complaints/:id/feedback`
- `GET /api/reports` (admin only)
- `GET /api/health`

## Important prototype note
This is a local academic project prototype. The JSON file database is suitable for a single-user/local demonstration, not concurrent production use. Before a real campus deployment, use a database such as PostgreSQL/MySQL, HTTPS, secure secrets, email verification, rate limiting, backups, audit logging, and administrator-managed staff accounts. The demo credentials are intentionally included for evaluation; change them before any deployment.
