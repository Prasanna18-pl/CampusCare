const API = "/api";
const TOKEN_KEY = "campuscare_token";
const CATEGORY_ICONS = {
  "Infrastructure": "🏢", "Electrical": "💡", "Wi-Fi / Computer": "📶",
  "Water & Sanitation": "🚰", "Cleanliness": "🧹", "Library": "📚", "Other": "🛠️"
};
const STATUSES = ["Pending", "Assigned", "In Progress", "Resolved"];
let currentUser = null;
let complaints = [];
let selectedRating = 0;

const $ = id => document.getElementById(id);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({
  "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
}[c]));
const statusClass = status => status.replace(/\s/g, "");
const dateText = value => new Date(value).toLocaleDateString(undefined, {day:"numeric", month:"short", year:"numeric"});
const token = () => localStorage.getItem(TOKEN_KEY);

async function api(path, options = {}) {
  const headers = options.headers || {};
  if (token()) headers.Authorization = `Bearer ${token()}`;
  if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  const response = await fetch(API + path, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed.");
  return data;
}
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}
function showAuth(mode) {
  $("loginForm").classList.toggle("hidden", mode !== "login");
  $("signupForm").classList.toggle("hidden", mode !== "signup");
}
function showApp() {
  $("authScreen").classList.add("hidden"); $("app").classList.remove("hidden");
  $("userLabel").textContent = `${currentUser.name} · ${currentUser.role}`;
  $("reportNav").classList.toggle("hidden", currentUser.role !== "admin");
  $("complaintTitle").textContent = currentUser.role === "student" ? "My complaints" : "All complaints";
}
function go(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === page));
  document.querySelectorAll(".nav").forEach(n => n.classList.toggle("active", n.dataset.page === page));
  if (page === "complaints") renderRows();
  window.scrollTo({top:0, behavior:"smooth"});
}
document.querySelectorAll(".nav").forEach(button => button.addEventListener("click", () => go(button.dataset.page)));
document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => go(button.dataset.go)));

$("showSignup").addEventListener("click", () => showAuth("signup"));
$("showLogin").addEventListener("click", () => showAuth("login"));

$("loginForm").addEventListener("submit", async event => {
  event.preventDefault(); $("loginError").textContent = "";
  try {
    const result = await api("/auth/login", {method:"POST", body:JSON.stringify({
      email:$("loginEmail").value.trim(), password:$("loginPassword").value
    })});
    localStorage.setItem(TOKEN_KEY, result.token); currentUser = result.user;
    showApp(); await refresh(); toast(`Welcome ${currentUser.name}!`);
  } catch (error) { $("loginError").textContent = error.message; }
});

$("signupForm").addEventListener("submit", async event => {
  event.preventDefault(); $("signupError").textContent = "";
  try {
    await api("/auth/register", {method:"POST", body:JSON.stringify({
      name:$("signupName").value.trim(), email:$("signupEmail").value.trim(),
      role:$("signupRole").value, password:$("signupPassword").value
    })});
    showAuth("login"); $("loginEmail").value = $("signupEmail").value.trim();
    $("loginError").textContent = "Account created. Please sign in.";
    event.target.reset();
  } catch (error) { $("signupError").textContent = error.message; }
});

$("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem(TOKEN_KEY); currentUser = null;
  $("app").classList.add("hidden"); $("authScreen").classList.remove("hidden");
  $("loginPassword").value = ""; showAuth("login");
});

async function refresh() {
  const result = await api("/complaints");
  complaints = result.complaints;
  renderDashboard(); renderRows();
  if (currentUser.role === "admin") await renderReports();
}
function visibleComplaints() { return complaints; }
function renderStats(target, rows) {
  const total = rows.length;
  const values = [
    ["Total complaints", total, "▤"],
    ["Awaiting action", rows.filter(c => c.status === "Pending").length, "◷"],
    ["Being handled", rows.filter(c => ["Assigned","In Progress"].includes(c.status)).length, "⚙"],
    ["Resolved", rows.filter(c => c.status === "Resolved").length, "✓"]
  ];
  $(target).innerHTML = values.map(([label, value, icon]) =>
    `<div class="stat"><span>${label} ${icon}</span><strong>${value}</strong><span>${total ? Math.round(value/total*100) : 0}% snapshot</span></div>`
  ).join("");
}
function renderCategories(target, rows) {
  const counts = {};
  rows.forEach(c => counts[c.category] = (counts[c.category] || 0) + 1);
  const total = rows.length || 1;
  $(target).innerHTML = Object.entries(counts).sort((a,b)=>b[1]-a[1]).map(([name,count]) =>
    `<div class="cat"><span>${CATEGORY_ICONS[name] || "🛠️"}</span><div>${esc(name)}<span style="float:right;color:#718096">${count}</span><div class="bar"><i style="width:${count/total*100}%"></i></div></div></div>`
  ).join("") || `<div class="empty">No data yet.</div>`;
}
function renderDashboard() {
  const rows = visibleComplaints();
  $("welcome").textContent = currentUser.role === "admin" ? "Admin overview 📊" :
    currentUser.role === "department" ? "Department workspace 🧰" : `Good day, ${currentUser.name}! 👋`;
  $("welcomeText").textContent = currentUser.role === "admin" ? "Monitor campus complaints and resolution trends." :
    currentUser.role === "department" ? "Review campus work and update complaint status." :
    "Track campus issues from submission to resolution.";
  renderStats("stats", rows); renderCategories("categories", rows);
  const recent = [...rows].sort((a,b)=>new Date(b.submitted)-new Date(a.submitted)).slice(0,4);
  $("recent").innerHTML = recent.map(c => `<div class="item"><div class="ico">${CATEGORY_ICONS[c.category] || "🛠️"}</div><div class="item-info"><b>${esc(c.title)}</b><small>${esc(c.id)} · ${esc(c.location)}</small><span class="pill ${statusClass(c.status)}">${esc(c.status)}</span></div><button class="secondary" data-detail="${esc(c.id)}">Details</button></div>`).join("") || `<div class="empty">No complaints submitted yet.</div>`;
  $("recent").querySelectorAll("[data-detail]").forEach(b => b.addEventListener("click", () => openDetail(b.dataset.detail)));
}
function renderRows() {
  if (!currentUser) return;
  const q = ($("search").value || "").toLowerCase(), st = $("filterStatus").value;
  const cat = $("filterCategory").value, priority = $("filterPriority").value;
  const rows = complaints.filter(c =>
    (!q || [c.id,c.title,c.location,c.category].some(v => String(v).toLowerCase().includes(q))) &&
    (!st || c.status === st) && (!cat || c.category === cat) && (!priority || c.priority === priority)
  );
  $("count").textContent = `${rows.length} records`;
  $("rows").innerHTML = rows.map(c => `<tr>
    <td><b>${esc(c.title)}</b><small>${esc(c.id)} · ${esc(c.owner)}</small></td>
    <td>${esc(c.category)}<small>${esc(c.location)}</small></td>
    <td><span class="pill ${esc(c.priority)}">${esc(c.priority)}</span></td>
    <td><span class="pill ${statusClass(c.status)}">${esc(c.status)}</span></td>
    <td>${dateText(c.submitted)}</td>
    <td>${currentUser.role === "student" ? `<button class="secondary" data-detail="${esc(c.id)}">Track</button>` :
      `<select data-status="${esc(c.id)}">${STATUSES.map(s=>`<option ${s===c.status?"selected":""}>${s}</option>`).join("")}</select>`}</td>
  </tr>`).join("");
  $("empty").classList.toggle("hidden", rows.length > 0);
  $("rows").querySelectorAll("[data-detail]").forEach(b => b.addEventListener("click", () => openDetail(b.dataset.detail)));
  $("rows").querySelectorAll("[data-status]").forEach(s => s.addEventListener("change", () => updateStatus(s.dataset.status, s.value)));
}
async function updateStatus(id, status) {
  try { await api(`/complaints/${encodeURIComponent(id)}/status`, {method:"PATCH", body:JSON.stringify({status})}); await refresh(); toast("Complaint status updated."); }
  catch (error) { toast(error.message); }
}
$("complaintForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const image = formData.get("image");
  if (image && image.size > 1.5 * 1024 * 1024) return toast("Image must be 1.5 MB or smaller.");
  if (!image || !image.name) formData.delete("image");
  try {
    const result = await api("/complaints", {method:"POST", body:formData});
    form.reset(); await refresh(); go("complaints"); toast(`Submitted. Your ID is ${result.complaint.id}`);
  } catch (error) { toast(error.message); }
});

async function openDetail(id) {
  try {
    const {complaint:c} = await api(`/complaints/${encodeURIComponent(id)}`);
    $("detailTitle").textContent = c.title;
    const history = (c.updates || []).map(u => `<div>● <b>${esc(u.status)}</b> — ${esc(u.note)}<small>${new Date(u.at).toLocaleString()}</small></div>`).join("");
    const feedback = c.status === "Resolved" && currentUser.role === "student" && c.rating == null ?
      `<hr><b>Rate the resolution</b><div class="stars">${[1,2,3,4,5].map(n=>`<button type="button" data-rating="${n}">★</button>`).join("")}</div><textarea id="feedbackText" placeholder="Optional feedback" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px"></textarea><button class="primary" id="sendFeedback" style="margin-top:10px">Submit feedback</button>` :
      (c.rating ? `<p>⭐ Feedback: ${c.rating}/5 · ${esc(c.feedback || "")}</p>` : "");
    $("detailBody").innerHTML = `<p><span class="pill ${statusClass(c.status)}">${esc(c.status)}</span> <span class="pill ${esc(c.priority)}">${esc(c.priority)} priority</span> <span class="pill">${esc(c.id)}</span></p>
      <p><b>Category:</b> ${esc(c.category)}<br><b>Location:</b> ${esc(c.location)}<br><b>Department:</b> ${esc(c.department || "Awaiting assignment")}<br><b>Submitted:</b> ${dateText(c.submitted)}</p>
      <p>${esc(c.description)}</p>${c.imageUrl ? `<img src="${esc(c.imageUrl)}" alt="Complaint attachment" style="max-width:100%;max-height:220px;border-radius:10px">` : ""}
      <h4>Status timeline</h4><div class="timeline">${history}</div>${feedback}`;
    selectedRating = 0;
    $("detailBody").querySelectorAll("[data-rating]").forEach(b => b.addEventListener("click", () => {
      selectedRating = Number(b.dataset.rating);
      $("detailBody").querySelectorAll("[data-rating]").forEach(x => x.classList.toggle("on", Number(x.dataset.rating) <= selectedRating));
    }));
    const send = $("sendFeedback");
    if (send) send.addEventListener("click", async () => {
      if (!selectedRating) return toast("Please select a star rating.");
      try {
        await api(`/complaints/${encodeURIComponent(id)}/feedback`, {method:"POST", body:JSON.stringify({rating:selectedRating, feedback:$("feedbackText").value.trim()})});
        $("modal").classList.add("hidden"); await refresh(); toast("Thank you for your feedback.");
      } catch (error) { toast(error.message); }
    });
    $("modal").classList.remove("hidden");
  } catch (error) { toast(error.message); }
}
$("closeModal").addEventListener("click", () => $("modal").classList.add("hidden"));
$("modal").addEventListener("click", e => { if (e.target === $("modal")) $("modal").classList.add("hidden"); });

async function renderReports() {
  if (currentUser.role !== "admin") return;
  const report = await api("/reports");
  renderStats("reportStats", report.complaints);
  renderCategories("reportCategories", report.complaints);
  const total = report.total || 1;
  $("reportStatuses").innerHTML = STATUSES.map(s => {
    const n = report.byStatus[s] || 0;
    return `<div class="cat"><div style="flex:1;font-size:12px;font-weight:700">${s}<span style="float:right;color:#718096">${n}</span><div class="bar"><i style="width:${n/total*100}%"></i></div></div></div>`;
  }).join("") + `<div class="notice">Resolution rate: <b>${Math.round((report.byStatus.Resolved || 0)/total*100)}%</b></div>`;
}
$("exportBtn").addEventListener("click", async () => {
  try {
    const {complaints:rows} = await api("/reports");
    const cols = ["id","title","category","location","priority","status","department","owner","submitted","description"];
    const csv = [cols, ...rows.map(r=>cols.map(k=>r[k] ?? ""))].map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv],{type:"text/csv"}));
    a.download = "campuscare-complaints.csv"; a.click(); URL.revokeObjectURL(a.href);
  } catch (error) { toast(error.message); }
});
["search","filterStatus","filterCategory","filterPriority"].forEach(id => $(id).addEventListener("input", renderRows));

async function boot() {
  if (!token()) return;
  try {
    const result = await api("/auth/me"); currentUser = result.user;
    showApp(); await refresh();
  } catch { localStorage.removeItem(TOKEN_KEY); }
}
boot();
