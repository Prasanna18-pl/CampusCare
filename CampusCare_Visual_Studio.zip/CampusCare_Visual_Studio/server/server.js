require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const crypto = require("crypto");
const { readDB, writeDB } = require("./db");
const { authenticate, allowRoles } = require("./middleware");

const app = express();
const PORT = process.env.PORT || 5000;
if (!process.env.JWT_SECRET) {
  console.warn("WARNING: JWT_SECRET is not set. Set it in your .env file before deployment.");
  process.env.JWT_SECRET = "development_only_change_this_secret";
}

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use(express.static(path.join(__dirname, "..", "public")));

const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 1.5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    cb(allowed.includes(file.mimetype) ? null : new Error("Only JPG, PNG or WEBP images are allowed."), allowed.includes(file.mimetype));
  }
});

const categories = ["Infrastructure", "Electrical", "Wi-Fi / Computer", "Water & Sanitation", "Cleanliness", "Library", "Other"];
const statuses = ["Pending", "Assigned", "In Progress", "Resolved"];
const departments = {
  "Infrastructure": "Maintenance",
  "Electrical": "Electrical Maintenance",
  "Wi-Fi / Computer": "IT Support",
  "Water & Sanitation": "Facilities Team",
  "Cleanliness": "Housekeeping",
  "Library": "Library Services",
  "Other": "Campus Administration"
};

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}
function makeToken(user) {
  return jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: "12h" });
}
function seedDemoUsers() {
  const db = readDB();
  const demos = [
    ["student@mitadt.edu.in", "student123", "Demo Student", "student"],
    ["staff@mitadt.edu.in", "staff123", "Department Staff", "department"],
    ["admin@mitadt.edu.in", "admin123", "Administrator", "admin"]
  ];
  let changed = false;
  for (const [email, password, name, role] of demos) {
    if (!db.users.some(u => u.email === email)) {
      db.users.push({ id: crypto.randomUUID(), email, passwordHash: bcrypt.hashSync(password, 10), name, role, createdAt: new Date().toISOString() });
      changed = true;
    }
  }
  if (changed) writeDB(db);
}
seedDemoUsers();

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "CampusCare API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body || {};
    const normalizedEmail = String(email || "").trim().toLowerCase();
    if (!name || !normalizedEmail || !password) return res.status(400).json({ message: "Name, email and password are required." });
    if (!normalizedEmail.endsWith("@mitadt.edu.in")) return res.status(400).json({ message: "Please use your @mitadt.edu.in university email." });
    if (String(password).length < 6) return res.status(400).json({ message: "Password must be at least 6 characters." });
    if (!["student", "department"].includes(role)) return res.status(400).json({ message: "Choose a valid account role." });

    const db = readDB();
    if (db.users.some(u => u.email === normalizedEmail)) return res.status(409).json({ message: "This email is already registered." });

    const user = {
      id: crypto.randomUUID(),
      name: String(name).trim(),
      email: normalizedEmail,
      passwordHash: await bcrypt.hash(String(password), 10),
      role,
      createdAt: new Date().toISOString()
    };
    db.users.push(user);
    writeDB(db);
    res.status(201).json({ message: "Account created. You can now sign in." });
  } catch (error) {
    res.status(500).json({ message: "Could not create account." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ message: "Incorrect email or password." });
  }
  res.json({ token: makeToken(user), user: publicUser(user) });
});

app.get("/api/auth/me", authenticate, (req, res) => res.json({ user: req.user }));

app.get("/api/complaints", authenticate, (req, res) => {
  const db = readDB();
  let rows = db.complaints;
  if (req.user.role === "student") rows = rows.filter(c => c.ownerId === req.user.id);
  const { status, category, priority, search } = req.query;
  if (status) rows = rows.filter(c => c.status === status);
  if (category) rows = rows.filter(c => c.category === category);
  if (priority) rows = rows.filter(c => c.priority === priority);
  if (search) {
    const q = String(search).toLowerCase();
    rows = rows.filter(c => [c.id, c.title, c.location, c.category].some(v => String(v || "").toLowerCase().includes(q)));
  }
  rows.sort((a, b) => new Date(b.submitted) - new Date(a.submitted));
  res.json({ complaints: rows });
});

app.post("/api/complaints", authenticate, upload.single("image"), (req, res) => {
  const { category, location, priority, title, description, contact } = req.body || {};
  if (!categories.includes(category) || !location || !title || !description) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ message: "Please complete all required complaint fields." });
  }
  if (!["Low", "Medium", "High"].includes(priority || "Medium")) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ message: "Choose a valid priority." });
  }

  const db = readDB();
  const nextNumber = 1001 + db.complaints.length;
  const now = new Date().toISOString();
  const complaint = {
    id: `CC-${new Date().getFullYear()}-${nextNumber}`,
    title: String(title).trim(),
    category,
    location: String(location).trim(),
    priority: priority || "Medium",
    status: "Pending",
    description: String(description).trim(),
    contact: String(contact || "").trim(),
    imageUrl: req.file ? `/uploads/${req.file.filename}` : "",
    ownerId: req.user.id,
    owner: req.user.name,
    department: departments[category],
    submitted: now,
    updates: [{ status: "Pending", note: "Complaint submitted", at: now }]
  };
  db.complaints.push(complaint);
  writeDB(db);
  res.status(201).json({ message: "Complaint submitted successfully.", complaint });
});

app.get("/api/complaints/:id", authenticate, (req, res) => {
  const db = readDB();
  const c = db.complaints.find(x => x.id === req.params.id);
  if (!c) return res.status(404).json({ message: "Complaint not found." });
  if (req.user.role === "student" && c.ownerId !== req.user.id) return res.status(403).json({ message: "You cannot view this complaint." });
  res.json({ complaint: c });
});

app.patch("/api/complaints/:id/status", authenticate, allowRoles("department", "admin"), (req, res) => {
  const nextStatus = req.body?.status;
  if (!statuses.includes(nextStatus)) return res.status(400).json({ message: "Invalid status." });
  const db = readDB();
  const c = db.complaints.find(x => x.id === req.params.id);
  if (!c) return res.status(404).json({ message: "Complaint not found." });
  c.status = nextStatus;
  c.updates = c.updates || [];
  c.updates.push({ status: nextStatus, note: `Status updated to ${nextStatus}`, at: new Date().toISOString() });
  if (nextStatus === "Resolved") c.resolvedAt = new Date().toISOString();
  writeDB(db);
  res.json({ message: "Complaint status updated.", complaint: c });
});

app.post("/api/complaints/:id/feedback", authenticate, (req, res) => {
  const rating = Number(req.body?.rating);
  const feedback = String(req.body?.feedback || "").trim();
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ message: "Rating must be from 1 to 5." });
  const db = readDB();
  const c = db.complaints.find(x => x.id === req.params.id);
  if (!c) return res.status(404).json({ message: "Complaint not found." });
  if (c.ownerId !== req.user.id || c.status !== "Resolved") return res.status(403).json({ message: "Feedback is available to the complaint owner after resolution." });
  c.rating = rating;
  c.feedback = feedback;
  writeDB(db);
  res.json({ message: "Thank you for your feedback.", complaint: c });
});

app.get("/api/reports", authenticate, allowRoles("admin"), (_req, res) => {
  const complaints = readDB().complaints;
  const byStatus = Object.fromEntries(statuses.map(s => [s, complaints.filter(c => c.status === s).length]));
  const byCategory = Object.fromEntries(categories.map(c => [c, complaints.filter(x => x.category === c).length]));
  res.json({ total: complaints.length, byStatus, byCategory, complaints });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  const message = err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE"
    ? "Image must be 1.5 MB or smaller."
    : (err.message || "Something went wrong.");
  res.status(400).json({ message });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));

app.listen(PORT, () => console.log(`CampusCare is running at http://localhost:${PORT}`));
