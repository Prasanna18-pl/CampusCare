const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "data", "db.json");

function ensureDatabase() {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [], complaints: [] }, null, 2));
  }
}

function readDB() {
  ensureDatabase();
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return { users: [], complaints: [] };
  }
}

function writeDB(db) {
  ensureDatabase();
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

module.exports = { readDB, writeDB };
